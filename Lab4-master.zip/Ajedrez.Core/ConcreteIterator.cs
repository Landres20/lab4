﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ajedrez.Core
{
    public class ConcreteIterator : Iterator
    {
        private ConcreteAggregate _aggregate;
        private int _actual = 0;

        public ConcreteIterator(ConcreteAggregate aggregate)
        {
            _aggregate = aggregate;
        }

        public override object ItemActual()
        {
            return _aggregate[_actual];
        }

        public override object First()
        {
            return _aggregate[0];
        }

        public override object isDone()
        {
            return _actual >= _aggregate.Count;
        }

        public override object Next()
        {
            object ret = null;

            if(_actual < _aggregate.Count - 1)
                ret = _aggregate[++_actual];

            return ret;
        }
    }
}
