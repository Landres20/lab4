﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Ajedrez.Core.Interfaces;

namespace Ajedrez.Core.Services
{
    public class servicioMovimiento : validacionMovimientos
    {
        public string esValido(ConcreteAggregate resultado)
        {
            Iterator i = resultado.createIterator();
            object pieza = i.First();
            
            while(pieza != null)
            {
                if ((bool)pieza)
                {
                    return "Es un movimiento valido";
                }
                pieza = i.Next();
            }
            return "No es un movimiento valido";
        }

        public string Movimientos(Pieza[] piezas, string linea)
        {
            ConcreteAggregate resultado = new ConcreteAggregate();
            int posicion = 0;

            foreach(var pieza in piezas)
            {
                resultado[posicion]=pieza.Movimiento(linea);
                posicion++;
            }
            return esValido(resultado);
        }
    }
}
