﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Ajedrez.Core.Interfaces;

namespace Ajedrez.Core.Services
{
    public class servicioPeon : Pieza
    {
        public bool Movimiento(string linea)
        {
            Regex peon = new Regex(@"^[a-h][1-8]-[a-h][1-8]");
            return (peon.IsMatch(linea)) ? true : false;
        }
    }
}
