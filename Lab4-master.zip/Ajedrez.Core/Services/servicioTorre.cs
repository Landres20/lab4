﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Ajedrez.Core.Interfaces;

namespace Ajedrez.Core.Services
{
    public class servicioTorre : Pieza
    {
        public bool Movimiento(string linea)
        {
            Regex torre = new Regex(@"^T[a-h][1-8]-[a-h][1-8]");
            return (torre.IsMatch(linea)) ? true : false;
        }
    }
}
