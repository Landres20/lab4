﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ajedrez.Core.Interfaces
{
    public interface validacionMovimientos
    {
        string Movimientos(Pieza[] piezas, string linea);
        string esValido(ConcreteAggregate resultados);
    }
}
