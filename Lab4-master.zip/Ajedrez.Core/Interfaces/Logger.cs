﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ajedrez.Core.Interfaces
{
    public interface Logger
    {
        static void Log(string mensaje) => throw new NotImplementedException();
    }
}
