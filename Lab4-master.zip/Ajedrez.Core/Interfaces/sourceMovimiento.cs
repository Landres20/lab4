﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ajedrez.Core.Interfaces
{
    public interface sourceMovimiento
    {
        StreamReader getMovimientoFuente(string archivo);
    }
}
