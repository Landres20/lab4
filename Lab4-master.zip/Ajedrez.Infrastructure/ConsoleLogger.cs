﻿using Ajedrez.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ajedrez.Infrastructure
{
    public class ConsoleLogger : Logger
    {
        private static ConsoleLogger _instance = null;

        protected ConsoleLogger() { }

        public static ConsoleLogger Instance()
        {
            if (_instance == null)
                _instance = new ConsoleLogger();

            return _instance;
        }

        public static void Log(string mensaje) => Console.WriteLine(mensaje);
    }
}
