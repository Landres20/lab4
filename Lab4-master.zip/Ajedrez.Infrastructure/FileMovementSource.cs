﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Ajedrez.Core.Interfaces;

namespace Ajedrez.Infrastructure
{
    public class FileMovementSource : sourceMovimiento
    {
        public StreamReader getMovimientoFuente(string file)
        {
            StreamReader File = new StreamReader(file);
            return File;
        }
    }
}
